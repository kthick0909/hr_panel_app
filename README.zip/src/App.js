import React from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

import Dashboard from "./components/pages/Dashboard";
import Home from "./components/pages/Home";
import Roles from "./components/pages/Roles";
import Company from "./components/pages/Company";
import Leaves from "./components/pages/Leaves";
import Attendance from "./components/pages/Attendance";
import Account from "./components/pages/Account";

import NotFound from "./components/pages/NotFound";

import User from "./components/users/User";
import AddUser from "./components/users/AddUser";
import EditUser from "./components/users/EditUser";

function App(props) {
  return (
    <Router>
      <div className="App">
        <Switch>
          <Route exact path="/" component={Dashboard} />
          <Route exact path="/roles" component={Roles} />
          <Route exact path="/company" component={Company} />
          <Route exact path="/user" component={Home} />
          <Route exact path="/leaves" component={Leaves} />
          <Route exact path="/attendance" component={Attendance} />
          <Route exact path="/account" component={Account} />
          <Route exact path="/users/add" component={AddUser} />
          <Route exact path="/users/edit/:id" component={EditUser} />
          <Route exact path="/users/:id" component={User} />
          <Route component={NotFound} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;
