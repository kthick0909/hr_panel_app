import React, { useState, useEffect } from "react";
import axios from "axios";
import { useHistory } from "react-router-dom";

const Home = () => {
  let history = useHistory();
  const [users, setUser] = useState([]);

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    const result = await axios.get("http://localhost:3003/users");
    setUser(result.data);
    console.log(result.data);
  };

  const deleteUser = async (id) => {
    await axios.delete(`http://localhost:3003/users/${id}`);
    alert("User deleted successfully");
    loadUsers();
  };
  const routeChange = () => {
    let path = `./users/add`;
    history.push(path);
  };
  return (
    <>
      <div
        style={{
          padding: "5px",
          boxShadow: "5px 5px 5px 5px #aaaaaa",
        }}
      >
        <div class="row">
          <div class="col-md-10">
            <h2 style={{ marginLeft: "20px" }}>
              Users
            </h2>
          </div>
          <div class="col-md-2">
            <button
              type="button"
              class="btn btn-info"
              style={{ marginTop: "20px", right: '0' }}
              onClick={routeChange}
            >
              <i class="zmdi zmdi-account-add zmdi-hc-lg"></i> &nbsp;Add User
            </button>
          </div>
        </div>
        <br></br>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">No.</th>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">Contact No.</th>
              <th scope="col">Status</th>
              <th scope="col">Image</th>
              <th scope="col" colspan="3">
                Action
              </th>
            </tr>
          </thead>
          <tbody>
            {users.map((user, index) => (
              <tr>
                <td scope="row">{index + 1}</td>
                <td>
                  {user.firstname} {user.lastname}
                </td>
                <td>{user.email}</td>
                <td>{user.mobileno}</td>
                <td>{user.status}</td>
                <td>
                  <img src={user.profile} width="50" height="40" />
                </td>
                <td>
                  <a href={`/users/edit/${user.id}`}>
                    <i class="zmdi zmdi-edit zmdi-hc-lg"></i>
                  </a>
                </td>
                <td>
                  <a href={`/users/${user.id}`} style={{ color: "green" }}>
                    <i class="zmdi zmdi-eye zmdi-hc-lg"></i>
                  </a>
                </td>
                <td>
                  <a
                    href="#"
                    onClick={() => deleteUser(user.id)}
                    style={{ color: "red" }}
                  >
                    <i class="zmdi zmdi-delete zmdi-hc-lg"></i>
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default Home;
