import React from 'react'

const Company = () => {
  return (
    <div>
        <h1>Company Page</h1>
    </div>
  )
}

export default Company