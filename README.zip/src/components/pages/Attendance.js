import React from 'react'

const Attendance = () => {
  return (
    <div>
        <h1>Attendance Page</h1>
    </div>
  )
}

export default Attendance