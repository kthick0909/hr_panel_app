import React from "react";
import BannerLogo from '../../assets/images/banner-logo.png'
const Dashboard = () => {
  return (
    <div>
      <h1 className="dashboard-h1">Welcome to HR Panel Dashboard, </h1>
      <img src={BannerLogo} />
    </div>
  );
};

export default Dashboard;
