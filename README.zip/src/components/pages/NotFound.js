import React from "react";
const NotFound = () => {
  return (
    <div>
      <div className="not-found">
        <h1>Page Not Found</h1>
      </div>
    </div>
  );
};

export default NotFound;
