import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link, useHistory, useParams } from "react-router-dom";


const User = () => {
  const { id } = useParams();
  const [user, setUser] = useState({
    firstname: "",
    lastname: "",
    designation: "",
    role: "",
    email: "",
    password: "",
    mobileno: "",
    DOB: "",
    gender: "",
    empid: "",
    company: "",
    status: "",
    resquetoken: "",
    profile: "",
  });
  const {
    firstname,
    lastname,
    designation,
    role,
    email,
    password,
    mobileno,
    DOB,
    gender,
    empid,
    company,
    status,
    resquetoken,
    profile,
  } = user;
 
  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const result = await axios.get(`http://localhost:3003/users/${id}`);
    setUser(result.data);
  };

  return (
    <div style={{ border: "1px solid #ddd", padding: "20px" }}>
     <div class="row">
        <div class="col-md-10">
          <h2 style={{ marginLeft: "20px" }}>{firstname} {lastname}</h2>
        </div>
        <div class="col-md-2">
          <Link class="btn btn-primary float-end" to="/user">
            Back to Home
          </Link>
        </div>
      </div>
      <hr></hr>
      <div class="row">
        <div class="col-md-4" style={{padding: "70px"}}>
        <img
              src={profile}
              alt="No Image with URL"
              width="150px"
              height="150px"
            />
        </div>
        <div class="col-md-8">
          <div class="row">
            <div class="col-md-4"><b><h4>First Name</h4></b></div>
            <div class="col-md-2">-</div>
            <div class="col-md-6"><b><h4>{firstname}</h4></b></div>
          </div>
          <div class="row">
            <div class="col-md-4"><b><h4>Last Name</h4></b></div>
            <div class="col-md-2">-</div>
            <div class="col-md-6"><b><h4>{lastname}</h4></b></div>
          </div>
          <div class="row">
            <div class="col-md-4"><b><h4>Designation</h4></b></div>
            <div class="col-md-2">-</div>
            <div class="col-md-6"><b><h4>{designation }</h4></b></div>
          </div>
          <div class="row">
            <div class="col-md-4"><b><h4>Role</h4></b></div>
            <div class="col-md-2">-</div>
            <div class="col-md-6"><b><h4>{role}</h4></b></div>
          </div>
          <div class="row">
            <div class="col-md-4"><b><h4>Email</h4></b></div>
            <div class="col-md-2">-</div>
            <div class="col-md-6"><b><h4>{email}</h4></b></div>
          </div>
          <div class="row">
            <div class="col-md-4"><b><h4>Password</h4></b></div>
            <div class="col-md-2">-</div>
            <div class="col-md-6">*******</div>
          </div>
          <div class="row">
            <div class="col-md-4"><b><h4>Mobile No.</h4></b></div>
            <div class="col-md-2">-</div>
            <div class="col-md-6"><b><h4>{mobileno}</h4></b></div>
          </div>
          <div class="row">
            <div class="col-md-4"><b><h4>Date of Birth</h4></b></div>
            <div class="col-md-2">-</div>
            <div class="col-md-6"><b><h4>{DOB}</h4></b></div>
          </div>
          <div class="row">
            <div class="col-md-4"><b><h4>Gender</h4></b></div>
            <div class="col-md-2">-</div>
            <div class="col-md-6"><b><h4>{gender}</h4></b></div>
          </div>
          <div class="row">
            <div class="col-md-4"><b><h4>Emp ID</h4></b></div>
            <div class="col-md-2">-</div>
            <div class="col-md-6"><b><h4>{empid}</h4></b></div>
          </div>
          <div class="row">
            <div class="col-md-4"><b><h4>Company</h4></b></div>
            <div class="col-md-2">-</div>
            <div class="col-md-6"><b><h4>{company}</h4></b></div>
          </div>
          <div class="row">
            <div class="col-md-4"><b><h4>Status</h4></b></div>
            <div class="col-md-2">-</div>
            <div class="col-md-6" style={status ==="InActive" ? {color: "red"} : {color: "green"}}><b><h4>{status}</h4></b></div>
          </div>
          <div class="row">
            <div class="col-md-4"><b><h4>Resque Time Token</h4></b></div>
            <div class="col-md-2">-</div>
            <div class="col-md-6"><b><h4>{resquetoken}</h4></b></div>
          </div>
        </div>
      </div>    
      </div>
  );
};

export default User;
