import React, { useState } from "react";
import axios from "axios";
import { Link, useHistory } from "react-router-dom";

const AddUser = () => {
  let history = useHistory();

  const [user, setUser] = useState({
    firstname: "",
    lastname: "",
    designation: "",
    role: "",
    email: "",
    password: "",
    mobileno: "",
    DOB: "",
    gender: "",
    empid: "",
    company: "",
    status: "",
    resquetoken: "",
    profile: "",
  });

  const {
    firstname,
    lastname,
    designation,
    role,
    email,
    password,
    mobileno,
    DOB,
    gender,
    empid,
    company,
    status,
    resquetoken,
    profile,
  } = user;
  user.status = "Active";
  const onInputChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:3003/users/", user);
    alert("User added successfully");
    history.push("/user");
  };

  const genderoptions = [
    { value: "", label: "Select Gender" },
    { value: "Male", label: "Male" },
    { value: "Female", label: "Female" },
    { value: "Others", label: "Others" },
  ];
  const designationoptions = [
    { value: "", label: "Select Designation  " },
    { value: "CEO", label: "CEO" },
    { value: "CTO", label: "CTO" },
    { value: "CIO", label: "CIO" },
    { value: "VP of Product Management", label: "VP of Product Management" },
    { value: "Product Manager", label: "Product Manager" },
    { value: "VP of Marketing", label: "VP of Marketing" },
    { value: "VP of Engineering", label: "VP of Engineering" },
    { value: "Chief Architect", label: "Chief Architect" },
    { value: "Software Architect", label: "Software Architect" },
    {
      value: "Engineering Project Manager",
      label: "Engineering Project Manager",
    },
    { value: "Team Lead", label: "Team Lead" },
    {
      value: "Principal Software Engineer",
      label: "Principal Software Engineer",
    },
    { value: "Senior Software Engineer", label: "Senior Software Engineer" },
    { value: "Software Engineer", label: "Software Engineer" },
    { value: "Software Developer", label: "Software Developer" },
    { value: "Junior Software Developer", label: "Junior Software Developer" },
    { value: "Intern Software Developer", label: "Intern Software Developer" },
  ];
  const statusoptions = [
    { value: "", label: "Select Status" },
    { value: "Active", label: "Active" },
    { value: "Inactive", label: "Inactive" },
  ];
  const roleoptions = [
    { value: "", label: "Select Role" },
    { value: "Admin", label: "Admin" },
    { value: "User", label: "User" },
  ];

  return (
    <div style={{ border: "1px solid #ddd", padding: "20px" }}>
      <div class="row">
        <div class="col-md-10">
          <h2 style={{ marginLeft: "20px" }}>Add Users</h2>
        </div>
        <div class="col-md-2">
          <Link class="btn btn-primary float-end" to="/user">
          <i class="zmdi zmdi-home"></i> &nbsp; Back to Home
          </Link>
        </div>
      </div>
      <hr></hr>

      <form class="form-horizontal"  onSubmit={(e) => onSubmit(e)}>
        <div class="form-group">
          <label for="First Name" class="col-sm-2 control-label">
            First Name
          </label>
          <div class="col-sm-10">
            <input
              type="text"
              className="form-control"
              placeholder="Enter First Name"
              name="firstname"
              value={firstname}
              onChange={(e) => onInputChange(e)}
              required
            />
          </div>
        </div>

        <div class="form-group">
          <label for="Last Name" class="col-sm-2 control-label">
            Last Name
          </label>
          <div class="col-sm-10">
            <input
              type="text"
              className="form-control form-control-sm"
              placeholder="Enter Last Name"
              name="lastname"
              value={lastname}
              onChange={(e) => onInputChange(e)}
              required
            />
          </div>
        </div>

        <div class="form-group">
          <label for="Last Name" class="col-sm-2 control-label">
            Designation
          </label>
          <div class="col-sm-10">
            <select
              name="designation"
              onChange={(e) => onInputChange(e)}
              className="form-control form-control-lg"
              required
            >
              {designationoptions.map((option) => (
                <option
                  value={option.value}
                  selected={designation === option.value}
                >
                  {option.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div class="form-group">
          <label for="Last Name" class="col-sm-2 control-label">
            Role
          </label>
          <div class="col-sm-10">
            <select
              name="role"
              onChange={(e) => onInputChange(e)}
              className="form-control form-control-lg"
              required
            >
              {roleoptions.map((option) => (
                <option value={option.value} selected={role === option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div class="form-group">
          <label for="Last Name" class="col-sm-2 control-label">
            Email
          </label>
          <div class="col-sm-10">
            <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter Email"
              name="email"
              value={email}
              onChange={(e) => onInputChange(e)}
              required
            />
          </div>
        </div>

        <div class="form-group">
          <label for="Last Name" class="col-sm-2 control-label">
            Password
          </label>
          <div class="col-sm-10">
            <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter Password"
              name="password"
              value={password}
              onChange={(e) => onInputChange(e)}
              required
            />
          </div>
        </div>

        <div class="form-group">
          <label for="Last Name" class="col-sm-2 control-label">
            Mobile No.
          </label>
          <div class="col-sm-10">
            <input
              type="number"
              className="form-control form-control-lg"
              placeholder="Enter Mobileno"
              name="mobileno"
              value={mobileno}
              onChange={(e) => onInputChange(e)}
              required
            />
          </div>
        </div>

        <div class="form-group">
          <label for="Last Name" class="col-sm-2 control-label">
            Date of Birth
          </label>
          <div class="col-sm-10">
            <input
              type="date"
              className="form-control form-control-lg"
              placeholder="Enter D.O.B"
              name="DOB"
              value={DOB}
              onChange={(e) => onInputChange(e)}
              required
            />
          </div>
        </div>

        <div class="form-group">
          <label for="Last Name" class="col-sm-2 control-label">
            Gender
          </label>
          <div class="col-sm-10">
            <select
              name="gender"
              onChange={(e) => onInputChange(e)}
              className="form-control form-control-lg"
              required
            >
              {genderoptions.map((option) => (
                <option value={option.value} selected={gender === option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div class="form-group">
          <label for="Last Name" class="col-sm-2 control-label">
            Emp ID
          </label>
          <div class="col-sm-10">
            <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter Emp ID"
              name="empid"
              value={empid}
              onChange={(e) => onInputChange(e)}
              required
            />
          </div>
        </div>

        <div class="form-group">
          <label for="Last Name" class="col-sm-2 control-label">
            Company
          </label>
          <div class="col-sm-10">
            <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter Company Name"
              name="company"
              value={company}
              onChange={(e) => onInputChange(e)}
              required
            />
          </div>
        </div>

        <div class="form-group">
          <label for="Resque Time Token" class="col-sm-2 control-label">
            Resque Time Token
          </label>
          <div class="col-sm-10">
            <input
              type="number"
              className="form-control form-control-lg"
              placeholder="Enter Resque Time Token"
              name="resquetoken"
              value={resquetoken}
              onChange={(e) => onInputChange(e)}
              required
            />
          </div>
        </div>

        <div class="row">
          <div class="col-xs-2">
            <label for="Profile Picture URL" class="col-sm-12 control-label" style={profile ==="" ? {} : { marginTop: "40px" }}>
              Profile Pic. URL
            </label>
          </div>
          <div class="col-xs-4">
            <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter Profile Picture URL"
              name="profile"
              value={profile}
              onChange={(e) => onInputChange(e)}
              style={profile ==="" ? {} : { marginTop: "40px" }}
              required
            />
          </div>
          <div class="col-xs-3">
            <img
              src={profile}
              alt="No Image with URL"
              width="150px"
              height="150px"
            />
          </div>
        </div>
        <hr></hr>
        <div class="form-group">
          <div class="col-sm-offset-2 col-sm-10">
            <button type="submit" class="btn btn-success btn-lg">
              Submit
            </button>
          </div>
        </div>
      </form>
      <br></br>
    </div>
  );
};

export default AddUser;
